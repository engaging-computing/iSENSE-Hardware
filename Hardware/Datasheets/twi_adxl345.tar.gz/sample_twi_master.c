#include <machinescience.h>
#include <twi_master.c>

/* Set TWI address of ADXL345 */
#define ADXL345 0x1D

/* Sends two bytes of data to the ADXL345 and expects nothing in return. */
void write_reg(unsigned char address, unsigned char data)
{
	/* Wait while TWI is busy */
	while(twiBusy());

	/* Sends two bytes of data to the ADXL345 not including the address byte. */
	twiMsgSize = 2;
	twiData[0] = ((ADXL345 << 1) | (TWI_WRITE));
	twiData[1] = address; 
	twiData[2] = data; 

	/* Initiate a TWI start condition. */
	TWCR = TWIMASTERSTART;
}

/* It looks like this will return all three axis in double bytes, but I don't
 * remember! Anyway, this is how you get multiple bytes from an TWI device. */
void read_axis(unsigned char *axis)
{
	int i;

	/* Send one byte of data. */
	while (twiBusy());
	twiMsgSize = 1;
	twiData[0] = ((ADXL345 << 1) | (TWI_WRITE));
	twiData[1] = 0x32;
	TWCR = TWIMASTERSTART;

	/* Ask for six bytes of data. */
	while (twiBusy());
	twiMsgSize = 6;
	twiData[0] = ((ADXL345 << 1) | (TWI_READ));
	TWCR = TWIMASTERSTART;

	/* Store data in buffer. */
	while (twiBusy());
	for (i = 0; i < 6; i++)
		axis[i] = twiData[i+1];
}

/* This is how you ask for one byte of data. */
unsigned char read_buffer(unsigned char address)
{
	/* Send one byte of data. */
	while (twiBusy());
	twiMsgSize = 1;
	twiData[0] = ((ADXL345 << 1) | (TWI_WRITE));
	twiData[1] = address;
	TWCR = TWIMASTERSTART;

	/* Ask for one or two bytes of data. */
	while (twiBusy());
	twiMsgSize = 2; //Note: I believe this must be set to at least 2
	twiData[0] = ((ADXL345 << 1) | (TWI_READ));
	TWCR = TWIMASTERSTART;

	/* Return received data. */
	while (twiBusy());
	/* Return one byte of data. */
	return twiData[1];
	/* Return two bytes of data. */
	//return (twiData[2] << 8) | twiData[1];
}

int main(void) {	
	/* Enable TWI master. Set bus speed to 175kHz. Enable global interrupts. Using
	 * twiMasterInit(bus speed); you can set the bus speed separately and call
	 * global interrupts using sei(); */
	network_control(ENABLE);

	/* Writes (0x28) to Power Control register (0x2D). This sets the link bit, don't
	 * remember why, and measure bit which places the part in measure mode. Check
	 * the datasheet. */
	write_reg( 0x2D, 0x28);

	/* Writes (0x00) to the Data Format register (0x31). I think this puts it in TWI
	 * mode. Gee, I should probably write comments when I am actually writing the
	 * code not a few months later! Anyway, the whole thing was very easy to get
	 * running so you should have no trouble. */
	write_reg( 0x31, 0x00);

	while (TRUE); 
}
